package controllers;

import views.View;

public class Loader {

	public static void main(String[] args) {
		new View();
		
		/*
		 * Date d = new Date(); System.out.println(d);
		 * 
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HHmmss"); String
		 * userDate = sdf.format(d); System.out.println(userDate.substring(0,
		 * userDate.indexOf(" "))); String date =
		 * userDate.substring(userDate.indexOf(" ")+1); System.out.println(date);
		 */
		 	
	}

}
