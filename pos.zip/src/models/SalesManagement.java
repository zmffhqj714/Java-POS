package models;

public class SalesManagement {
	
	public SalesManagement() {}
	
	public void backController(String jobCode) {

		switch(jobCode) {
		case "4":
			this.ctlSales();
			break;
		}
	}
	
	/* 판매개시 */
	private void ctlSales() {
		
	}
}
