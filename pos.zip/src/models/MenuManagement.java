package models;

public class MenuManagement {
	private DataAccessObject dao;

	public MenuManagement() {

	}

	public String backController(String jobCode) {
		String message = null;
		switch(jobCode) {
		case "21":
			message = this.ctlReadMenu();
			break;
		case "22":
			this.ctlModMenu();
			break;
		case "23":
			this.ctlDelMenu();
			break;
		case "24":
			this.ctlRegGoods();
			break;
		case "25":
			this.ctlModGoods();
			break;
		case "26":
			this.ctlDelGoods();
			break;
		}
		return message;
	}

	public String backController(String jobCode, String[] data) {
		String message = null;
		
		switch(jobCode) {
		case "2R":
			message = this.ctlRegMenu(data);
			break;
		}
		return message;
	}
	
	
	/* 메뉴읽기 */
	private String ctlReadMenu() {
		String menuList = null;
		dao = new DataAccessObject();
		menuList = this.toStringFromArray(dao.getMenu());
		
		return menuList;
	}
	
	/* 2차원 배열 --> String */
	private String toStringFromArray(String[][] menuList) {
		StringBuffer sb = new StringBuffer();
		
		for(int recordIndex=0; recordIndex<menuList.length; recordIndex++) {
			sb.append(" ");
			for(int colIndex=0; colIndex<menuList[recordIndex].length; colIndex++) {
				if(colIndex == 3) {
					sb.append(menuList[recordIndex][colIndex].equals("1")? "가능": "불가");
				}else {
					sb.append(menuList[recordIndex][colIndex]);
				}

				if(colIndex != menuList[recordIndex].length - 1) {
					sb.append("\t");
					if(colIndex == 1 && menuList[recordIndex][colIndex].length()<6) {
						sb.append("\t");
					}
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	
	/* 메뉴등록 */
	private String ctlRegMenu(String[] menuData) {
		String menuList = null;
		dao = new DataAccessObject();
		// DAO에 메뉴등록 요청
		if(dao.setMenu(menuData)) {
			// DAO에 등록된 메뉴 읽기 요청
			menuList = this.toStringFromArray(dao.getMenu());
		}else {
			menuList = "메뉴등록작업이 실패하였습니다. 다시 한번 입력해주세요";
		}
		
		// 등록메뉴를 리턴
		return menuList;
	}
	
	/* 메뉴수정 */
	private void ctlModMenu() {

	}

	/* 메뉴삭제 */
	private void ctlDelMenu() {

	}

	/* 굿즈등록 */
	private void ctlRegGoods() {

	}

	/* 굿즈정보수정 */
	private void ctlModGoods() {

	}

	/* 굿즈 삭제 */
	private void ctlDelGoods() {

	}
}
